(function( app ) {

	var ui = app.ns("ui");

	ui.InfoPanel = ui.DraggablePanel.extend({
		_baseCls: "uiPanel uiInfoPanel"
	});

})( this.app );
