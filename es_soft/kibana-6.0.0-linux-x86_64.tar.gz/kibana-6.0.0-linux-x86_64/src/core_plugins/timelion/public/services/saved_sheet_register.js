import './saved_sheets';

export default function savedSearchObjectFn(savedSheets) {
  return savedSheets;
}
