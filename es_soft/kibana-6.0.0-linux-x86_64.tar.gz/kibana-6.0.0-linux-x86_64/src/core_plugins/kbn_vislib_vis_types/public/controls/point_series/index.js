import 'plugins/kbn_vislib_vis_types/controls/point_series/value_axes.js';
import 'plugins/kbn_vislib_vis_types/controls/point_series/category_axis.js';
import 'plugins/kbn_vislib_vis_types/controls/point_series/series.js';
import 'plugins/kbn_vislib_vis_types/controls/point_series/grid.js';
