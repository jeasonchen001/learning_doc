'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.BytesFormat = undefined;

var _numeral = require('./_numeral');

const BytesFormat = exports.BytesFormat = _numeral.Numeral.factory({
  id: 'bytes',
  title: 'Bytes'
});
